// src/agentd/index.ts
var import_os7 = require("os");
var import_path8 = require("path");

// src/main/wikihome.ts
var import_fs2 = require("fs");
var import_child_process = require("child_process");
var import_os = require("os");
var import_path2 = require("path");

// src/main/docs.ts
var import_fs = require("fs");
var import_path = require("path");

// src/shared/frontmatter.ts
var ORDER = ["author", "created", "updated"];
function serializeFrontmatter(meta, body) {
  const lines = ORDER.filter((k) => meta[k] != null).map((k) => `${k}: ${meta[k]}`);
  if (lines.length === 0) return body;
  const block = `---
${lines.join("\n")}
---
`;
  return body ? `${block}
${body}` : block;
}
function parseFrontmatter(md) {
  const m = /^---\r?\n([\s\S]*?)\r?\n---[ \t]*(?:\r?\n|$)/.exec(md);
  if (!m) return { meta: {}, body: md };
  const meta = {};
  for (const raw of m[1].split(/\r?\n/)) {
    const mm = /^(\w+):\s*(.*)$/.exec(raw.trim());
    if (!mm) continue;
    const [, key, value] = mm;
    if (key === "author") {
      if (value === "human" || value === "claude") meta.author = value;
    } else if (key === "created") {
      meta.created = value;
    } else if (key === "updated") {
      meta.updated = value;
    }
  }
  let body = md.slice(m[0].length);
  if (body.startsWith("\n")) body = body.slice(1);
  else if (body.startsWith("\r\n")) body = body.slice(2);
  return { meta, body };
}

// src/shared/wikilinks.ts
var WIKILINK = /\[\[([^[\]|]+)\]\]/g;
function slug(s) {
  return s.toLowerCase().replace(/\.md$/, "").replace(/[\s_-]+/g, "-").trim();
}
function libraryDocs(docs) {
  return docs.filter(
    (d) => d.relPath.toLowerCase().endsWith(".md") && d.name !== "CLAUDE.md" && !d.relPath.startsWith("files/") && !d.relPath.startsWith("builds/")
  );
}
function pathSegs(relPath) {
  return relPath.replace(/\.md$/i, "").split("/").map(slug);
}
function dirSegs(relPath) {
  const segs = pathSegs(relPath);
  segs.pop();
  return segs;
}
function sharedPrefixLen(a, b) {
  let i = 0;
  while (i < a.length && i < b.length && a[i] === b[i]) i++;
  return i;
}
function byNearest(a, b) {
  const da = a.relPath.split("/").length;
  const db = b.relPath.split("/").length;
  return da !== db ? da - db : a.relPath.localeCompare(b.relPath);
}
function resolveWikilink(name, docs, sourceRelPath) {
  const lib = libraryDocs(docs);
  if (name.includes("/")) {
    const wanted = pathSegs(name);
    const matches2 = lib.filter((d) => {
      const segs = pathSegs(d.relPath);
      if (segs.length < wanted.length) return false;
      const tail = segs.slice(segs.length - wanted.length);
      return tail.every((s, i) => s === wanted[i]);
    });
    if (matches2.length === 0) return null;
    return matches2.sort(byNearest)[0];
  }
  const target = slug(name);
  const matches = lib.filter((d) => slug(d.name) === target);
  if (matches.length === 0) return null;
  const srcSegs = sourceRelPath ? pathSegs(sourceRelPath) : [];
  return matches.sort((a, b) => {
    const pa = sharedPrefixLen(dirSegs(a.relPath), srcSegs);
    const pb = sharedPrefixLen(dirSegs(b.relPath), srcSegs);
    if (pa !== pb) return pb - pa;
    return byNearest(a, b);
  })[0];
}
function mapWikilinks(md, fn) {
  return md.split(/(```[\s\S]*?```)/).map(
    (seg, i) => i % 2 === 1 ? seg : seg.replace(WIKILINK, (whole, name) => {
      const next = fn(name);
      return next == null ? whole : `[[${next}]]`;
    })
  ).join("");
}

// src/main/docs.ts
var SKIP_DIRS = /* @__PURE__ */ new Set(["node_modules", ".git", "dist", "out"]);
var MAX_FILES = 200;
var MAX_DEPTH = 6;
function shouldSkipDir(name) {
  return SKIP_DIRS.has(name);
}
function isDoc(name) {
  const lower = name.toLowerCase();
  return lower.endsWith(".md") || lower.endsWith(".txt");
}
function listDocs(dir) {
  if (!dir) return [];
  let root;
  try {
    root = (0, import_path.resolve)(dir);
    if (!(0, import_fs.statSync)(root).isDirectory()) return [];
  } catch {
    return [];
  }
  const out = [];
  const walk = (current, depth) => {
    if (depth > MAX_DEPTH || out.length >= MAX_FILES) return;
    let entries;
    try {
      entries = (0, import_fs.readdirSync)(current, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      if (out.length >= MAX_FILES) break;
      if (entry.isDirectory()) {
        if (!shouldSkipDir(entry.name)) walk((0, import_path.join)(current, entry.name), depth + 1);
      } else if (entry.isFile() && isDoc(entry.name)) {
        const full = (0, import_path.join)(current, entry.name);
        out.push({ name: entry.name, relPath: (0, import_path.relative)(root, full), path: full, mtimeMs: (0, import_fs.statSync)(full).mtimeMs });
      }
    }
  };
  walk(root, 1);
  out.sort((a, b) => a.relPath.localeCompare(b.relPath));
  return out;
}
function guardDocPath(path, dir) {
  const root = (0, import_path.resolve)(dir);
  const target = (0, import_path.resolve)(path);
  if (!target.startsWith(root + import_path.sep) || !isDoc(target)) {
    throw new Error("Refusing to touch a file outside the wiki home.");
  }
  return target;
}
function readDoc(path, dir) {
  return (0, import_fs.readFileSync)(guardDocPath(path, dir), "utf8");
}
function writeDoc(path, dir, content) {
  (0, import_fs.writeFileSync)(guardDocPath(path, dir), content);
}
function entryFor(root, full) {
  return {
    name: full.slice(full.lastIndexOf(import_path.sep) + 1),
    relPath: (0, import_path.relative)(root, full),
    path: full,
    mtimeMs: (0, import_fs.statSync)(full).mtimeMs
  };
}
function seedDoc() {
  const now = (/* @__PURE__ */ new Date()).toISOString();
  return serializeFrontmatter({ author: "human", created: now, updated: now }, "");
}
function createDoc(dir) {
  const root = (0, import_path.resolve)(dir);
  let name = "Untitled.md";
  for (let n = 2; (0, import_fs.existsSync)((0, import_path.join)(root, name)); n++) name = `Untitled ${n}.md`;
  const full = (0, import_path.join)(root, name);
  (0, import_fs.writeFileSync)(full, seedDoc());
  return entryFor(root, full);
}
function sanitizeDocTitle(title) {
  const clean2 = title.replace(/\.md$/i, "").replace(/[\\/]+/g, "-").trim();
  return clean2 || "Repo";
}
function createNamedDoc(dir, title) {
  const root = (0, import_path.resolve)(dir);
  const base = sanitizeDocTitle(title);
  let name = `${base}.md`;
  for (let n = 2; (0, import_fs.existsSync)((0, import_path.join)(root, name)); n++) name = `${base} ${n}.md`;
  const full = (0, import_path.join)(root, name);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  (0, import_fs.writeFileSync)(
    full,
    serializeFrontmatter({ author: "human", created: now, updated: now }, "_Generating read-out from the repository\u2026_\n")
  );
  return entryFor(root, full);
}
function createChildDoc(home, parentRelPath) {
  const root = (0, import_path.resolve)(home);
  const base = parentRelPath.replace(/\.md$/i, "");
  const folder = (0, import_path.resolve)(root, base);
  if (!folder.startsWith(root + import_path.sep)) throw new Error("Refusing to nest outside the wiki home.");
  (0, import_fs.mkdirSync)(folder, { recursive: true });
  let name = "Untitled.md";
  for (let n = 2; (0, import_fs.existsSync)((0, import_path.join)(folder, name)); n++) name = `Untitled ${n}.md`;
  const full = (0, import_path.join)(folder, name);
  (0, import_fs.writeFileSync)(full, seedDoc());
  return entryFor(root, full);
}
function createDocInFolder(home, folderRelPath, title) {
  const root = (0, import_path.resolve)(home);
  const folder = folderRelPath ? (0, import_path.resolve)(root, folderRelPath) : root;
  if (folder !== root && !folder.startsWith(root + import_path.sep)) {
    throw new Error("Refusing to create outside the wiki home.");
  }
  (0, import_fs.mkdirSync)(folder, { recursive: true });
  const base = sanitizeDocTitle(title);
  let name = `${base}.md`;
  for (let n = 2; (0, import_fs.existsSync)((0, import_path.join)(folder, name)); n++) name = `${base} ${n}.md`;
  const full = (0, import_path.join)(folder, name);
  (0, import_fs.writeFileSync)(full, seedDoc());
  return entryFor(root, full);
}
function renameDoc(path, dir, title) {
  const root = (0, import_path.resolve)(dir);
  const from = guardDocPath(path, dir);
  const clean2 = title.trim();
  if (!clean2 || clean2.includes("/") || clean2.includes(import_path.sep)) {
    throw new Error("Invalid document name.");
  }
  const to = (0, import_path.join)((0, import_path.dirname)(from), clean2.endsWith(".md") ? clean2 : clean2 + ".md");
  guardDocPath(to, dir);
  if ((0, import_fs.existsSync)(to)) throw new Error("A document with that name already exists.");
  const oldBase = (0, import_path.basename)(from).replace(/\.md$/i, "");
  const childFolder = (0, import_path.join)((0, import_path.dirname)(from), oldBase);
  const newChildFolder = (0, import_path.join)((0, import_path.dirname)(from), clean2.replace(/\.md$/i, ""));
  const hasChildFolder = childFolder !== to && (0, import_fs.existsSync)(childFolder) && (0, import_fs.statSync)(childFolder).isDirectory();
  if (hasChildFolder && (0, import_fs.existsSync)(newChildFolder)) {
    throw new Error("A document with that name already exists.");
  }
  const before = libraryDocs(listDocs(root));
  const fromRel = (0, import_path.relative)(root, from);
  (0, import_fs.renameSync)(from, to);
  if (hasChildFolder) (0, import_fs.renameSync)(childFolder, newChildFolder);
  rewriteInboundLinks(root, before, fromRel, (0, import_path.relative)(root, to), clean2.replace(/\.md$/i, ""));
  return entryFor(root, to);
}
function rewriteInboundLinks(root, before, fromRel, toRel, newTitle) {
  for (const d of before) {
    const current = d.relPath === fromRel ? (0, import_path.join)(root, toRel) : d.path;
    let body;
    try {
      body = (0, import_fs.readFileSync)(current, "utf8");
    } catch {
      continue;
    }
    const next = mapWikilinks(body, (target) => {
      if (resolveWikilink(target, before, d.relPath)?.relPath !== fromRel) return null;
      const slash = target.lastIndexOf("/");
      return slash === -1 ? newTitle : target.slice(0, slash + 1) + newTitle;
    });
    if (next !== body) (0, import_fs.writeFileSync)(current, next);
  }
}
function stampAgentDocs(dir, known) {
  for (const d of listDocs(dir)) {
    if (d.relPath.startsWith("builds/") || d.relPath.startsWith("files/")) continue;
    if (known.has(d.path)) continue;
    let content;
    try {
      content = (0, import_fs.readFileSync)(d.path, "utf8");
    } catch {
      continue;
    }
    if (parseFrontmatter(content).body !== content) continue;
    let created = (/* @__PURE__ */ new Date()).toISOString();
    try {
      created = new Date((0, import_fs.statSync)(d.path).birthtimeMs).toISOString();
    } catch {
    }
    try {
      (0, import_fs.writeFileSync)(
        d.path,
        serializeFrontmatter({ author: "claude", created, updated: (/* @__PURE__ */ new Date()).toISOString() }, content)
      );
    } catch {
    }
  }
}
var docsWatcher = null;
var docsDebounce = null;
var startupKnown = /* @__PURE__ */ new Set();
var watchedDir = null;
function watchDocs(dir, onChange) {
  if (docsWatcher && watchedDir === dir) return;
  if (docsWatcher) {
    docsWatcher.close();
    docsWatcher = null;
  }
  watchedDir = dir || null;
  if (!dir) return;
  startupKnown = new Set(listDocs(dir).map((d) => d.path));
  try {
    docsWatcher = (0, import_fs.watch)(dir, { recursive: true }, () => {
      if (docsDebounce) clearTimeout(docsDebounce);
      docsDebounce = setTimeout(() => {
        stampAgentDocs(dir, startupKnown);
        onChange();
      }, 300);
    });
  } catch {
    docsWatcher = null;
  }
}

// src/main/wikihome.ts
function defaultWikiHome() {
  return (0, import_path2.join)((0, import_os.homedir)(), "Olivetti");
}
var activeWikiHome = null;
function ensureWikiHome(dir, opts) {
  const home = (0, import_path2.resolve)(dir && dir.trim() ? dir.trim() : defaultWikiHome());
  if (opts?.dryRun) return home;
  const fresh = !(0, import_fs2.existsSync)(home);
  (0, import_fs2.mkdirSync)((0, import_path2.join)(home, "builds"), { recursive: true });
  (0, import_fs2.mkdirSync)((0, import_path2.join)(home, "files"), { recursive: true });
  if (fresh) createDoc(home);
  if (!(0, import_fs2.existsSync)((0, import_path2.join)(home, ".git"))) {
    (0, import_child_process.execFile)("git", ["init"], { cwd: home }, () => {
    });
  }
  activeWikiHome = home;
  return home;
}
function ensureBuildDir(home, slug2) {
  if (!/^[a-z0-9][a-z0-9-]*$/.test(slug2)) {
    throw new Error("Invalid build workspace name.");
  }
  const dir = (0, import_path2.join)((0, import_path2.resolve)(home), "builds", slug2);
  (0, import_fs2.mkdirSync)(dir, { recursive: true });
  return dir;
}

// src/main/sessionMeta.ts
var import_fs3 = require("fs");
var import_os2 = require("os");
var import_path3 = require("path");
function parseSessionFile(jsonText) {
  try {
    const o = JSON.parse(jsonText);
    if (!o || typeof o.sessionId !== "string") return null;
    return {
      claudeId: o.sessionId,
      name: typeof o.name === "string" ? o.name : void 0,
      status: typeof o.status === "string" ? o.status : void 0
    };
  } catch {
    return null;
  }
}
function readAllSessionMeta(dir) {
  let files;
  try {
    files = (0, import_fs3.readdirSync)(dir).filter((f) => f.endsWith(".json"));
  } catch {
    return [];
  }
  const out = [];
  for (const f of files) {
    try {
      const m = parseSessionFile((0, import_fs3.readFileSync)((0, import_path3.join)(dir, f), "utf8"));
      if (m) out.push(m);
    } catch {
    }
  }
  return out;
}
var SESSIONS_DIR = (0, import_path3.join)((0, import_os2.homedir)(), ".claude", "sessions");
function watchSessionMeta(onMeta) {
  onMeta(readAllSessionMeta(SESSIONS_DIR));
  let timer = null;
  let watcher = null;
  try {
    watcher = (0, import_fs3.watch)(SESSIONS_DIR, () => {
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => onMeta(readAllSessionMeta(SESSIONS_DIR)), 150);
    });
  } catch {
  }
  return () => {
    if (timer) clearTimeout(timer);
    watcher?.close();
  };
}

// src/agentd/server.ts
var import_http = require("http");
var import_ws = require("ws");

// src/shared/wire.ts
function parseWireMessage(raw) {
  let msg;
  try {
    msg = JSON.parse(raw);
  } catch {
    return null;
  }
  if (typeof msg !== "object" || msg === null) return null;
  const m = msg;
  if (m.t === "req" && typeof m.id === "number" && typeof m.channel === "string") {
    return m;
  }
  if (m.t === "res" && typeof m.id === "number" && typeof m.ok === "boolean") {
    return m;
  }
  if (m.t === "evt" && typeof m.channel === "string") {
    return m;
  }
  return null;
}

// src/agentd/handlers.ts
var import_os6 = require("os");
var import_path7 = require("path");
var import_fs9 = require("fs");

// src/shared/ipc.ts
var IPC = {
  termOpen: "term:open",
  termInput: "term:input",
  termResize: "term:resize",
  termClose: "term:close",
  termData: "term:data",
  termExit: "term:exit",
  sessionMeta: "session:meta",
  pickDirectory: "dialog:pickDirectory",
  listDocs: "docs:list",
  readDoc: "docs:read",
  wikiEnsure: "wiki:ensure",
  docsWrite: "docs:write",
  docsCreate: "docs:create",
  docsCreateNamed: "docs:createNamed",
  docsCreateChild: "docs:createChild",
  docsCreateInFolder: "docs:createInFolder",
  docsRename: "docs:rename",
  docsTrash: "docs:trash",
  wikiBuildDir: "wiki:buildDir",
  filesImport: "files:import",
  filesOpen: "files:open",
  watchDocs: "docs:watch",
  docsChanged: "docs:changed",
  suggestionsRead: "suggestions:read",
  suggestionsClear: "suggestions:clear",
  repoRoot: "repo:root",
  termBuffer: "term:buffer",
  termList: "term:list",
  sessionsRead: "sessions:read",
  sessionsWrite: "sessions:write",
  sessionsChanged: "sessions:changed",
  presence: "presence",
  analyzeLine: "analyzer:line",
  analyzeFollowUp: "analyzer:followUp",
  setAnthropicKey: "analyzer:setKey",
  analyzerStatus: "analyzer:status",
  themeGet: "theme:get",
  themeSet: "theme:set",
  cloudSettingsGet: "cloud:settingsGet",
  cloudSettingsSet: "cloud:settingsSet",
  // 'proj:' prefix avoids colliding with the repo-scaffold channel 'projects:scaffold'.
  projList: "proj:list",
  projAdd: "proj:add",
  projRemove: "proj:remove",
  projRetry: "proj:retry",
  projShareLink: "proj:shareLink",
  projStatus: "proj:status"
};

// src/main/terminal.ts
var import_fs4 = require("fs");
var import_os3 = require("os");
var import_node_pty = require("node-pty");

// src/main/ringbuffer.ts
var RingBuffer = class {
  constructor(maxBytes) {
    this.maxBytes = maxBytes;
  }
  chunks = [];
  bytes = 0;
  append(chunk) {
    this.chunks.push(chunk);
    this.bytes += Buffer.byteLength(chunk);
    while (this.bytes > this.maxBytes && this.chunks.length > 1) {
      const removed = this.chunks.shift();
      this.bytes -= Buffer.byteLength(removed);
    }
  }
  contents() {
    return this.chunks.join("");
  }
};

// src/main/terminal-args.ts
function launchArgsFor(args, spawnedBefore) {
  if (spawnedBefore && args[0] === "--session-id") return ["--resume", args[1]];
  return args;
}
function ptyToken(scan) {
  return scan.replace(/\x1b\[[0-9;?]*[ -/]*[@-~]/g, "").replace(/\x1b[\]P^_][^\x07\x1b]*(?:\x07|\x1b\\)/g, "").replace(/\s+/g, "").toLowerCase();
}
function isMissingConversation(scan) {
  return ptyToken(scan).includes("noconversationfoundwithsessionid");
}
function isTrustPrompt(scan) {
  return ptyToken(scan).includes("yes,itrustthisfolder");
}
function recreateArgs(args) {
  const id = conversationIdOf(args);
  return id ? ["--session-id", id] : null;
}
function conversationIdOf(args) {
  const i = args.findIndex((a) => a === "--session-id" || a === "--resume");
  return i >= 0 ? args[i + 1] : void 0;
}

// src/main/session-confirm.ts
var COLOR_RE = /Session color set to:\s*([A-Za-z]+)/;
var RENAME_RE = /Session renamed to:\s*(.+)/;
var ANSI_RE = /\x1b\[[0-9;]*[A-Za-z]/g;
function clean(s) {
  return s.replace(ANSI_RE, "").trim();
}
function scanForSessionMeta(text) {
  const out = {};
  const c = text.match(COLOR_RE);
  if (c) out.color = c[1];
  const n = text.match(RENAME_RE);
  if (n) {
    const name = clean(n[1]);
    if (name) out.name = name;
  }
  return out;
}

// src/main/terminal.ts
var BUFFER_BYTES = 256 * 1024;
var CLAUDE_BIN = "claude";
var SKIP_PERMISSIONS = "--dangerously-skip-permissions";
var STARTUP_QUIET_MS = 2e3;
var terms = /* @__PURE__ */ new Map();
var everSpawned = /* @__PURE__ */ new Set();
function resolveCwd(cwd) {
  return cwd && (0, import_fs4.existsSync)(cwd) ? cwd : (0, import_os3.homedir)();
}
function openTerminal(sessionId, cwd, onData, onExit, onMeta, args = []) {
  const existing = terms.get(sessionId);
  if (existing) {
    existing.onData = onData;
    existing.onExit = onExit;
    existing.onMeta = onMeta;
    onData(existing.buffer.contents(), true);
    return;
  }
  const convId = conversationIdOf(args);
  const dir = resolveCwd(cwd);
  const launch = (launchArgs, canHeal) => {
    let pty;
    try {
      pty = (0, import_node_pty.spawn)(CLAUDE_BIN, [SKIP_PERMISSIONS, ...launchArgs], {
        name: "xterm-256color",
        cols: 80,
        rows: 24,
        cwd: dir,
        env: { ...process.env, COLORTERM: "truecolor" }
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      onData(`\r
Failed to launch \`claude\`: ${msg}\r
`, true);
      onExit(1);
      return;
    }
    const term = {
      pty,
      buffer: new RingBuffer(BUFFER_BYTES),
      spawnedAt: Date.now(),
      tail: "",
      onData,
      onExit,
      onMeta
    };
    terms.set(sessionId, term);
    if (convId != null) everSpawned.add(convId);
    const resuming = launchArgs[0] === "--resume" || launchArgs[0] === "--continue";
    let healing = false;
    let sawTrust = false;
    let trustHandled = false;
    let lastTrustPoke = 0;
    pty.onData((chunk) => {
      const scan = term.tail + chunk;
      const meta = scanForSessionMeta(scan);
      if (meta.color || meta.name) term.onMeta(meta);
      term.tail = scan.slice(-256);
      if (!trustHandled && isTrustPrompt(scan)) {
        sawTrust = true;
        const now = Date.now();
        if (now - lastTrustPoke > 250) {
          pty.write("\r");
          lastTrustPoke = now;
        }
        term.tail = "";
        return;
      }
      if (sawTrust) trustHandled = true;
      if (canHeal && resuming && (healing || isMissingConversation(scan))) {
        healing = true;
        return;
      }
      term.buffer.append(chunk);
      term.onData(chunk, Date.now() - term.spawnedAt < STARTUP_QUIET_MS);
    });
    pty.onExit(({ exitCode }) => {
      terms.delete(sessionId);
      const recreate = healing ? recreateArgs(launchArgs) : null;
      if (recreate) {
        launch(recreate, false);
        return;
      }
      term.onExit(exitCode);
    });
  };
  launch(launchArgsFor(args, convId != null && everSpawned.has(convId)), convId != null);
}
function listTerminals() {
  return [...terms.keys()];
}
function writeTerminal(sessionId, data) {
  terms.get(sessionId)?.pty.write(data);
}
function readTerminalBuffer(sessionId) {
  return terms.get(sessionId)?.buffer.contents() ?? "";
}
function resizeTerminal(sessionId, cols, rows) {
  try {
    terms.get(sessionId)?.pty.resize(cols, rows);
  } catch {
  }
}
function closeTerminal(sessionId) {
  const term = terms.get(sessionId);
  if (!term) return;
  term.pty.kill();
  terms.delete(sessionId);
}

// src/main/suggestions.ts
var import_fs5 = require("fs");
var import_path4 = require("path");
function suggestionsDir(home) {
  return (0, import_path4.join)((0, import_path4.resolve)(home), ".alexandria", "suggestions");
}
function sidecarPath(home, slug2) {
  const root = (0, import_path4.resolve)(home);
  const target = (0, import_path4.resolve)(suggestionsDir(home), `${slug2}.json`);
  return target.startsWith(root + import_path4.sep) ? target : null;
}
function clearSuggestions(home, slug2) {
  const target = sidecarPath(home, slug2);
  if (target) (0, import_fs5.rmSync)(target, { force: true });
}
function readSuggestions(home, slug2) {
  const target = sidecarPath(home, slug2);
  if (!target || !(0, import_fs5.existsSync)(target)) return null;
  try {
    return (0, import_fs5.readFileSync)(target, "utf8");
  } catch {
    return null;
  }
}

// src/main/projects.ts
var import_fs6 = require("fs");
var import_os4 = require("os");
var import_path5 = require("path");
function conventionalRepoRoot() {
  const dir = (0, import_path5.join)((0, import_os4.homedir)(), "repo");
  return (0, import_fs6.existsSync)((0, import_path5.join)(dir, ".git")) ? dir : null;
}

// src/main/session-store.ts
var import_fs7 = require("fs");
function readSessions(file) {
  try {
    const parsed = JSON.parse((0, import_fs7.readFileSync)(file, "utf8"));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}
function writeSessions(file, sessions) {
  const tmp = file + ".tmp";
  (0, import_fs7.writeFileSync)(tmp, JSON.stringify(sessions, null, 2));
  (0, import_fs7.renameSync)(tmp, file);
}

// src/agentd/trash.ts
var import_fs8 = require("fs");
var import_os5 = require("os");
var import_path6 = require("path");
async function trashPath(p, trashRoot = (0, import_path6.join)((0, import_os5.homedir)(), ".olivetti", "trash")) {
  if (!(0, import_fs8.existsSync)(p)) throw new Error(`trashPath: no such path: ${p}`);
  (0, import_fs8.mkdirSync)(trashRoot, { recursive: true });
  (0, import_fs8.renameSync)(p, (0, import_path6.join)(trashRoot, `${Date.now()}-${(0, import_path6.basename)(p)}`));
}

// src/agentd/handlers.ts
function buildHandlers(opts = {}) {
  const sessionsFile = () => {
    const f = opts.sessionsFile ?? (0, import_path7.join)((0, import_os6.homedir)(), ".olivetti", "sessions.json");
    (0, import_fs9.mkdirSync)((0, import_path7.dirname)(f), { recursive: true });
    return f;
  };
  return {
    [IPC.termOpen]: ({ sessionId, cwd, args }, ctx) => openTerminal(
      sessionId,
      cwd,
      (chunk, quiet) => ctx.emit(IPC.termData, { sessionId, chunk, quiet }),
      (code) => ctx.emit(IPC.termExit, { sessionId, code }),
      // SESSION_BRIDGE_ENABLED gate from index.ts is deliberately not reproduced here;
      // agentd always emits session meta, and the fragile parsing lives in sessionMeta.ts/session-confirm.ts.
      (meta) => ctx.emit(IPC.sessionMeta, { kind: "pty", sessionId, name: meta.name, color: meta.color }),
      args
    ),
    [IPC.termInput]: ({ sessionId, data }) => writeTerminal(sessionId, data),
    [IPC.termResize]: ({ sessionId, cols, rows }) => resizeTerminal(sessionId, cols, rows),
    [IPC.termClose]: ({ sessionId }) => closeTerminal(sessionId),
    [IPC.termBuffer]: ({ sessionId }) => readTerminalBuffer(sessionId),
    [IPC.termList]: () => listTerminals(),
    [IPC.listDocs]: ({ dir }) => listDocs(dir),
    [IPC.readDoc]: ({ path, dir }) => readDoc(path, dir),
    [IPC.wikiEnsure]: ({ dir }) => ensureWikiHome(dir ?? opts.defaultWikiDir ?? null),
    [IPC.docsWrite]: ({ path, dir, content }) => writeDoc(path, dir, content),
    [IPC.docsCreate]: ({ dir }) => createDoc(dir),
    [IPC.docsCreateNamed]: ({ dir, title }) => createNamedDoc(dir, title),
    [IPC.docsCreateChild]: ({ home, parentRelPath }) => createChildDoc(home, parentRelPath),
    [IPC.docsCreateInFolder]: ({ home, folderRelPath, title }) => createDocInFolder(home, folderRelPath, title),
    [IPC.docsRename]: ({ path, dir, title }) => renameDoc(path, dir, title),
    [IPC.docsTrash]: ({ path, dir }) => trashPath(guardDocPath(path, dir)),
    [IPC.wikiBuildDir]: ({ home, slug: slug2 }) => ensureBuildDir(home, slug2),
    [IPC.watchDocs]: ({ dir }, ctx) => {
      watchDocs(dir, () => ctx.emit(IPC.docsChanged, void 0));
    },
    [IPC.suggestionsRead]: ({ home, slug: slug2 }) => readSuggestions(home, slug2),
    [IPC.suggestionsClear]: ({ home, slug: slug2 }) => clearSuggestions(home, slug2),
    // Per-project local agentds (defaultWikiDir set) run on the user's machine
    // where ~/repo may exist for unrelated reasons — the desktop answers local
    // projects from its registry instead, so they report no backend repo here.
    [IPC.repoRoot]: () => opts.defaultWikiDir ? null : conventionalRepoRoot(),
    [IPC.sessionsRead]: () => readSessions(sessionsFile()),
    [IPC.sessionsWrite]: ({ sessions }, ctx) => {
      writeSessions(sessionsFile(), sessions);
      ctx.emit(IPC.sessionsChanged, void 0);
    }
  };
}

// src/agentd/server.ts
function startAgentd(opts) {
  const clients = /* @__PURE__ */ new Set();
  const broadcast = (channel, payload) => {
    const msg = JSON.stringify({ t: "evt", channel, payload });
    for (const ws of clients) if (ws.readyState === import_ws.WebSocket.OPEN) ws.send(msg);
  };
  const peers = /* @__PURE__ */ new Map();
  const sendPresence = () => broadcast("presence", { peers: [...peers.values()] });
  const ctx = { emit: broadcast };
  const handlers = buildHandlers(opts);
  const http = (0, import_http.createServer)((req, res) => {
    if (req.url === "/healthz") {
      res.writeHead(200, { "content-type": "text/plain", "access-control-allow-origin": "*" });
      res.end("ok");
    } else {
      res.writeHead(404);
      res.end();
    }
  });
  const wss = new import_ws.WebSocketServer({ server: http, path: "/ws" });
  wss.on("connection", (ws, req) => {
    const url = new URL(req.url ?? "/", "http://sprite");
    if (opts.token) {
      const header = req.headers.authorization;
      const query = url.searchParams.get("token");
      if (header !== `Bearer ${opts.token}` && query !== opts.token) {
        ws.close(4401, "unauthorized");
        return;
      }
    }
    clients.add(ws);
    peers.set(ws, url.searchParams.get("name") ?? "anonymous");
    sendPresence();
    ws.on("close", () => {
      clients.delete(ws);
      peers.delete(ws);
      sendPresence();
    });
    ws.on("message", (raw) => void handleMessage(ws, raw.toString()));
  });
  async function handleMessage(ws, raw) {
    const msg = parseWireMessage(raw);
    if (!msg) return;
    if (msg.t === "evt") {
      try {
        await handlers[msg.channel]?.(msg.payload, ctx);
      } catch (err) {
        console.error(`agentd: event ${msg.channel} failed:`, err);
      }
      return;
    }
    if (msg.t !== "req") return;
    const handler = handlers[msg.channel];
    let res;
    if (!handler) {
      res = { t: "res", id: msg.id, ok: false, error: `unknown channel: ${msg.channel}` };
    } else {
      try {
        const result = await handler(msg.args, ctx);
        res = { t: "res", id: msg.id, ok: true, result: result ?? null };
      } catch (err) {
        res = { t: "res", id: msg.id, ok: false, error: err instanceof Error ? err.message : String(err) };
      }
    }
    if (ws.readyState === import_ws.WebSocket.OPEN) ws.send(JSON.stringify(res));
  }
  return new Promise((resolve4) => {
    http.listen(opts.port, opts.host, () => {
      const addr = http.address();
      const port = typeof addr === "object" && addr ? addr.port : opts.port;
      const address = typeof addr === "object" && addr ? addr.address : "";
      resolve4({
        port,
        address,
        broadcast,
        close: () => new Promise((done) => {
          for (const ws of clients) ws.terminate();
          wss.close(() => http.close(() => done()));
        })
      });
    });
  });
}

// src/agentd/index.ts
process.env.PATH = `${(0, import_os7.homedir)()}/.local/bin:${process.env.PATH ?? ""}`;
async function main() {
  const dataDir = process.env.AGENTD_DATA_DIR;
  const wikiDir = dataDir ? (0, import_path8.join)(dataDir, "Olivetti") : null;
  const home = ensureWikiHome(wikiDir);
  const port = Number(process.env.AGENTD_PORT ?? 8080);
  const agentd = await startAgentd({
    port,
    ...process.env.AGENTD_HOST ? { host: process.env.AGENTD_HOST } : {},
    ...process.env.AGENTD_TOKEN ? { token: process.env.AGENTD_TOKEN } : {},
    ...wikiDir ? { defaultWikiDir: wikiDir } : {},
    ...dataDir ? { sessionsFile: (0, import_path8.join)(dataDir, "sessions.json") } : {}
  });
  watchSessionMeta((metas) => agentd.broadcast("session:meta", { kind: "file", metas }));
  console.log(`agentd listening on :${agentd.port}, wiki at ${home}`);
}
main().catch((err) => {
  console.error("agentd failed to start:", err);
  process.exit(1);
});
