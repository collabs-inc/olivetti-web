// src/agentd/index.ts
var import_os7 = require("os");
var import_path10 = require("path");

// src/main/wikihome.ts
var import_fs2 = require("fs");
var import_child_process = require("child_process");
var import_os = require("os");
var import_path2 = require("path");

// src/main/docs.ts
var import_fs = require("fs");
var import_path = require("path");
var SKIP_DIRS = /* @__PURE__ */ new Set(["node_modules", ".git", "dist", "out"]);
var MAX_FILES = 200;
var MAX_DEPTH = 6;
function shouldSkipDir(name) {
  return SKIP_DIRS.has(name);
}
function isDoc(name) {
  return name.toLowerCase().endsWith(".json");
}
function listDocs(dir) {
  if (!dir) return [];
  let root;
  try {
    root = (0, import_path.resolve)(dir);
    if (!(0, import_fs.statSync)(root).isDirectory()) return [];
  } catch {
    return [];
  }
  const out = [];
  const walk = (current2, depth) => {
    if (depth > MAX_DEPTH || out.length >= MAX_FILES) return;
    let entries;
    try {
      entries = (0, import_fs.readdirSync)(current2, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      if (out.length >= MAX_FILES) break;
      if (entry.isDirectory()) {
        if (!shouldSkipDir(entry.name)) walk((0, import_path.join)(current2, entry.name), depth + 1);
      } else if (entry.isFile() && isDoc(entry.name)) {
        const full = (0, import_path.join)(current2, entry.name);
        out.push(entryFor(root, full));
      }
    }
  };
  walk(root, 1);
  out.sort(compareDocEntries);
  return out;
}
function guardDocPath(path, dir) {
  const root = (0, import_path.resolve)(dir);
  const target = (0, import_path.resolve)(path);
  if (!target.startsWith(root + import_path.sep) || !isDoc(target)) {
    throw new Error("Refusing to touch a file outside the wiki home.");
  }
  return target;
}
function readDoc(path, dir) {
  return (0, import_fs.readFileSync)(guardDocPath(path, dir), "utf8");
}
function writeDoc(path, dir, content) {
  (0, import_fs.writeFileSync)(guardDocPath(path, dir), content);
}
function basenameTitle(full) {
  return (0, import_path.basename)(full).replace(/\.json$/i, "");
}
function entryFor(root, full) {
  const st = (0, import_fs.statSync)(full);
  return {
    name: basenameTitle(full),
    relPath: (0, import_path.relative)(root, full),
    path: full,
    createdMs: docCreatedMs(full, st.birthtimeMs || st.mtimeMs),
    mtimeMs: st.mtimeMs
  };
}
function compareDocEntries(a, b) {
  const byCreated = (a.createdMs ?? 0) - (b.createdMs ?? 0);
  return byCreated || a.relPath.localeCompare(b.relPath);
}
function docCreatedMs(full, fallback) {
  try {
    const raw = (0, import_fs.readFileSync)(full, "utf8");
    const meta = JSON.parse(raw).meta;
    const created = meta?.created ? Date.parse(meta.created) : NaN;
    return Number.isFinite(created) ? created : fallback;
  } catch {
    return fallback;
  }
}
function seedDoc(title) {
  const now = (/* @__PURE__ */ new Date()).toISOString();
  return JSON.stringify({ meta: { title, author: "human", created: now, updated: now }, blocks: [] }, null, 2);
}
function createDoc(dir) {
  const root = (0, import_path.resolve)(dir);
  let name = "Untitled.json";
  for (let n = 2; (0, import_fs.existsSync)((0, import_path.join)(root, name)); n++) name = `Untitled ${n}.json`;
  const full = (0, import_path.join)(root, name);
  (0, import_fs.writeFileSync)(full, seedDoc(name.replace(/\.json$/i, "")));
  return entryFor(root, full);
}
function sanitizeDocTitle(title) {
  const clean2 = title.replace(/\.json$/i, "").replace(/[\\/]+/g, "-").trim();
  return clean2 || "Repo";
}
function sanitizeRenameTitle(title) {
  const clean2 = title.trim().replace(/\.json$/i, "").replace(/[\\/:\x00-\x1f]+/g, "-").replace(/\s+/g, " ").trim().replace(/^-+|-+$/g, "").trim().slice(0, 80).trim();
  return clean2 || "Untitled";
}
function createNamedDoc(dir, title) {
  const root = (0, import_path.resolve)(dir);
  const base = sanitizeDocTitle(title);
  let name = `${base}.json`;
  for (let n = 2; (0, import_fs.existsSync)((0, import_path.join)(root, name)); n++) name = `${base} ${n}.json`;
  const full = (0, import_path.join)(root, name);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const doc = {
    meta: { title: name.replace(/\.json$/i, ""), author: "human", created: now, updated: now },
    blocks: [{ type: "paragraph", content: "Generating read-out from the repository\u2026" }]
  };
  (0, import_fs.writeFileSync)(full, JSON.stringify(doc, null, 2));
  return entryFor(root, full);
}
function createChildDoc(home, parentRelPath) {
  const root = (0, import_path.resolve)(home);
  const base = parentRelPath.replace(/\.json$/i, "");
  const folder = (0, import_path.resolve)(root, base);
  if (!folder.startsWith(root + import_path.sep)) throw new Error("Refusing to nest outside the wiki home.");
  (0, import_fs.mkdirSync)(folder, { recursive: true });
  let name = "Untitled.json";
  for (let n = 2; (0, import_fs.existsSync)((0, import_path.join)(folder, name)); n++) name = `Untitled ${n}.json`;
  const full = (0, import_path.join)(folder, name);
  (0, import_fs.writeFileSync)(full, seedDoc(name.replace(/\.json$/i, "")));
  return entryFor(root, full);
}
function createDocInFolder(home, folderRelPath, title) {
  const root = (0, import_path.resolve)(home);
  const folder = folderRelPath ? (0, import_path.resolve)(root, folderRelPath) : root;
  if (folder !== root && !folder.startsWith(root + import_path.sep)) {
    throw new Error("Refusing to create outside the wiki home.");
  }
  (0, import_fs.mkdirSync)(folder, { recursive: true });
  const base = sanitizeDocTitle(title);
  let name = `${base}.json`;
  for (let n = 2; (0, import_fs.existsSync)((0, import_path.join)(folder, name)); n++) name = `${base} ${n}.json`;
  const full = (0, import_path.join)(folder, name);
  (0, import_fs.writeFileSync)(full, seedDoc(name.replace(/\.json$/i, "")));
  return entryFor(root, full);
}
function renameDoc(path, dir, title) {
  const root = (0, import_path.resolve)(dir);
  const from = guardDocPath(path, dir);
  const folder = (0, import_path.dirname)(from);
  const base = sanitizeRenameTitle(title);
  const taken = new Set(
    (0, import_fs.readdirSync)(folder, { withFileTypes: true }).filter((entry) => entry.isFile() && isDoc(entry.name)).map((entry) => (0, import_path.join)(folder, entry.name)).filter((full) => (0, import_path.resolve)(full) !== from).map((full) => (0, import_path.basename)(full, (0, import_path.extname)(full)).toLowerCase())
  );
  const oldBase = (0, import_path.basename)(from).replace(/\.json$/i, "");
  const childFolder = (0, import_path.join)(folder, oldBase);
  const hasChildFolder = (0, import_fs.existsSync)(childFolder) && (0, import_fs.statSync)(childFolder).isDirectory();
  const available = (candidate) => {
    if (taken.has(candidate.toLowerCase())) return false;
    if (!hasChildFolder) return true;
    const candidateFolder = (0, import_path.join)(folder, candidate);
    return !(0, import_fs.existsSync)(candidateFolder) || (0, import_path.resolve)(candidateFolder) === (0, import_path.resolve)(childFolder);
  };
  let clean2 = base;
  for (let n = 2; !available(clean2); n++) clean2 = `${base} ${n}`;
  const to = (0, import_path.join)(folder, `${clean2}.json`);
  guardDocPath(to, dir);
  if ((0, import_path.resolve)(to) !== from) {
    (0, import_fs.renameSync)(from, to);
    if (hasChildFolder) (0, import_fs.renameSync)(childFolder, (0, import_path.join)(folder, clean2));
  }
  syncDocTitle(to, clean2);
  return entryFor(root, to);
}
function syncDocTitle(path, title) {
  try {
    const doc = JSON.parse((0, import_fs.readFileSync)(path, "utf8"));
    (0, import_fs.writeFileSync)(
      path,
      JSON.stringify(
        { ...doc, meta: { ...doc.meta, title, updated: (/* @__PURE__ */ new Date()).toISOString() } },
        null,
        2
      )
    );
  } catch {
  }
}
function stampAgentDocs(dir, known) {
  for (const d of listDocs(dir)) {
    if (d.relPath.startsWith("builds/") || d.relPath.startsWith("files/")) continue;
    if (known.has(d.path)) continue;
    let content;
    try {
      content = (0, import_fs.readFileSync)(d.path, "utf8");
    } catch {
      continue;
    }
    let doc;
    try {
      doc = JSON.parse(content);
    } catch {
      continue;
    }
    if (doc.meta?.author) continue;
    let created = doc.meta?.created ?? (/* @__PURE__ */ new Date()).toISOString();
    if (!doc.meta?.created) {
      try {
        created = new Date((0, import_fs.statSync)(d.path).birthtimeMs).toISOString();
      } catch {
      }
    }
    const title = doc.meta?.title ?? (0, import_path.basename)(d.path).replace(/\.json$/i, "");
    const next = {
      ...doc,
      meta: { ...doc.meta, title, author: "claude", created, updated: (/* @__PURE__ */ new Date()).toISOString() }
    };
    try {
      (0, import_fs.writeFileSync)(d.path, JSON.stringify(next, null, 2));
    } catch {
    }
  }
}
var docsWatcher = null;
var docsDebounce = null;
var startupKnown = /* @__PURE__ */ new Set();
var watchedDir = null;
function watchDocs(dir, onChange) {
  if (docsWatcher && watchedDir === dir) return;
  if (docsWatcher) {
    docsWatcher.close();
    docsWatcher = null;
  }
  watchedDir = dir || null;
  if (!dir) return;
  startupKnown = new Set(listDocs(dir).map((d) => d.path));
  try {
    docsWatcher = (0, import_fs.watch)(dir, { recursive: true }, () => {
      if (docsDebounce) clearTimeout(docsDebounce);
      docsDebounce = setTimeout(() => {
        stampAgentDocs(dir, startupKnown);
        onChange();
      }, 300);
    });
  } catch {
    docsWatcher = null;
  }
}

// src/main/instance.ts
function wikiHomeNameFor(suffix) {
  return suffix ? `Olivetti-${suffix}` : "Olivetti";
}
var current = "";
function getInstanceSuffix() {
  return current;
}

// src/main/wikihome.ts
function defaultWikiHome() {
  return (0, import_path2.join)((0, import_os.homedir)(), wikiHomeNameFor(getInstanceSuffix()));
}
var activeWikiHome = null;
function getActiveWikiHome() {
  return activeWikiHome;
}
function ensureWikiHome(dir, opts) {
  const home = (0, import_path2.resolve)(dir && dir.trim() ? dir.trim() : defaultWikiHome());
  if (opts?.dryRun) return home;
  const fresh = !(0, import_fs2.existsSync)(home);
  (0, import_fs2.mkdirSync)((0, import_path2.join)(home, "builds"), { recursive: true });
  (0, import_fs2.mkdirSync)((0, import_path2.join)(home, "files"), { recursive: true });
  if (fresh) createDoc(home);
  if (!(0, import_fs2.existsSync)((0, import_path2.join)(home, ".git"))) {
    (0, import_child_process.execFile)("git", ["init"], { cwd: home }, () => {
    });
  }
  activeWikiHome = home;
  return home;
}
function ensureBuildDir(home, slug) {
  if (!/^[a-z0-9][a-z0-9-]*$/.test(slug)) {
    throw new Error("Invalid build workspace name.");
  }
  const dir = (0, import_path2.join)((0, import_path2.resolve)(home), "builds", slug);
  (0, import_fs2.mkdirSync)(dir, { recursive: true });
  return dir;
}

// src/main/sessionMeta.ts
var import_fs3 = require("fs");
var import_os2 = require("os");
var import_path3 = require("path");
function parseSessionFile(jsonText) {
  try {
    const o = JSON.parse(jsonText);
    if (!o || typeof o.sessionId !== "string") return null;
    return {
      claudeId: o.sessionId,
      name: typeof o.name === "string" ? o.name : void 0,
      status: typeof o.status === "string" ? o.status : void 0
    };
  } catch {
    return null;
  }
}
function readAllSessionMeta(dir) {
  let files;
  try {
    files = (0, import_fs3.readdirSync)(dir).filter((f) => f.endsWith(".json"));
  } catch {
    return [];
  }
  const out = [];
  for (const f of files) {
    try {
      const m = parseSessionFile((0, import_fs3.readFileSync)((0, import_path3.join)(dir, f), "utf8"));
      if (m) out.push(m);
    } catch {
    }
  }
  return out;
}
var SESSIONS_DIR = (0, import_path3.join)((0, import_os2.homedir)(), ".claude", "sessions");
function watchSessionMeta(onMeta) {
  onMeta(readAllSessionMeta(SESSIONS_DIR));
  let timer = null;
  let watcher = null;
  try {
    watcher = (0, import_fs3.watch)(SESSIONS_DIR, () => {
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => onMeta(readAllSessionMeta(SESSIONS_DIR)), 150);
    });
  } catch {
  }
  return () => {
    if (timer) clearTimeout(timer);
    watcher?.close();
  };
}

// src/agentd/server.ts
var import_http = require("http");
var import_ws = require("ws");

// src/shared/wire.ts
function parseWireMessage(raw) {
  let msg;
  try {
    msg = JSON.parse(raw);
  } catch {
    return null;
  }
  if (typeof msg !== "object" || msg === null) return null;
  const m = msg;
  if (m.t === "req" && typeof m.id === "number" && typeof m.channel === "string") {
    return m;
  }
  if (m.t === "res" && typeof m.id === "number" && typeof m.ok === "boolean") {
    return m;
  }
  if (m.t === "evt" && typeof m.channel === "string") {
    return m;
  }
  return null;
}

// src/agentd/handlers.ts
var import_os6 = require("os");
var import_path9 = require("path");
var import_fs10 = require("fs");

// src/shared/ipc.ts
var IPC = {
  termOpen: "term:open",
  termInput: "term:input",
  termResize: "term:resize",
  termClose: "term:close",
  termData: "term:data",
  termExit: "term:exit",
  termShellOpen: "termShell:open",
  termShellInput: "termShell:input",
  termShellResize: "termShell:resize",
  termShellClose: "termShell:close",
  termShellData: "termShell:data",
  termShellExit: "termShell:exit",
  sessionMeta: "session:meta",
  pickDirectory: "dialog:pickDirectory",
  listDocs: "docs:list",
  readDoc: "docs:read",
  wikiEnsure: "wiki:ensure",
  docsWrite: "docs:write",
  docsCreate: "docs:create",
  docsCreateNamed: "docs:createNamed",
  docsCreateChild: "docs:createChild",
  docsCreateInFolder: "docs:createInFolder",
  docsRename: "docs:rename",
  docsTrash: "docs:trash",
  wikiBuildDir: "wiki:buildDir",
  filesImport: "files:import",
  filesOpen: "files:open",
  watchDocs: "docs:watch",
  docsChanged: "docs:changed",
  suggestionsRead: "suggestions:read",
  suggestionsClear: "suggestions:clear",
  repoRoot: "repo:root",
  termBuffer: "term:buffer",
  termList: "term:list",
  sessionsRead: "sessions:read",
  sessionsWrite: "sessions:write",
  sessionsChanged: "sessions:changed",
  presence: "presence",
  analyzeLine: "analyzer:line",
  analyzeFollowUp: "analyzer:followUp",
  setAnthropicKey: "analyzer:setKey",
  analyzerStatus: "analyzer:status",
  themeGet: "theme:get",
  accentGet: "accent:get",
  accentSet: "accent:set",
  themeSet: "theme:set",
  cloudSettingsGet: "cloud:settingsGet",
  cloudSettingsSet: "cloud:settingsSet",
  // 'proj:' prefix avoids colliding with the repo-scaffold channel 'projects:scaffold'.
  projList: "proj:list",
  projAdd: "proj:add",
  projRemove: "proj:remove",
  projRetry: "proj:retry",
  projShareLink: "proj:shareLink",
  projStatus: "proj:status",
  ghPrView: "gh:prView",
  ghIssueView: "gh:issueView",
  gitCommits: "git:commits",
  ghIssueCreate: "gh:issueCreate",
  ghIssueList: "gh:issueList",
  ghPrList: "gh:prList",
  openExternal: "shell:openExternal",
  briefingFacts: "briefing:facts",
  briefingGenerate: "briefing:generate",
  briefingHistory: "briefing:history",
  readoutChanged: "readout:changed",
  repoClone: "repo:clone"
};

// src/main/terminal.ts
var import_fs4 = require("fs");
var import_os3 = require("os");
var import_node_pty = require("node-pty");

// src/main/ringbuffer.ts
var RingBuffer = class {
  constructor(maxBytes) {
    this.maxBytes = maxBytes;
  }
  chunks = [];
  bytes = 0;
  append(chunk) {
    this.chunks.push(chunk);
    this.bytes += Buffer.byteLength(chunk);
    while (this.bytes > this.maxBytes && this.chunks.length > 1) {
      const removed = this.chunks.shift();
      this.bytes -= Buffer.byteLength(removed);
    }
  }
  contents() {
    return this.chunks.join("");
  }
};

// src/main/terminal-args.ts
function launchArgsFor(args, spawnedBefore) {
  if (spawnedBefore && args[0] === "--session-id") return ["--resume", args[1]];
  return args;
}
function ptyToken(scan) {
  return scan.replace(/\x1b\[[0-9;?]*[ -/]*[@-~]/g, "").replace(/\x1b[\]P^_][^\x07\x1b]*(?:\x07|\x1b\\)/g, "").replace(/\s+/g, "").toLowerCase();
}
function isMissingConversation(scan) {
  return ptyToken(scan).includes("noconversationfoundwithsessionid");
}
function isTrustPrompt(scan) {
  return ptyToken(scan).includes("yes,itrustthisfolder");
}
function recreateArgs(args) {
  const id = conversationIdOf(args);
  return id ? ["--session-id", id] : null;
}
function conversationIdOf(args) {
  const i = args.findIndex((a) => a === "--session-id" || a === "--resume");
  return i >= 0 ? args[i + 1] : void 0;
}

// src/main/session-confirm.ts
var COLOR_RE = /Session color set to:\s*([A-Za-z]+)/;
var RENAME_RE = /Session renamed to:\s*(.+)/;
var ANSI_RE = /\x1b\[[0-9;]*[A-Za-z]/g;
function clean(s) {
  return s.replace(ANSI_RE, "").trim();
}
function scanForSessionMeta(text) {
  const out = {};
  const c = text.match(COLOR_RE);
  if (c) out.color = c[1];
  const n = text.match(RENAME_RE);
  if (n) {
    const name = clean(n[1]);
    if (name) out.name = name;
  }
  return out;
}

// src/main/shell-spawn.ts
function shellSpawnSpec(env) {
  const bin = env.SHELL && env.SHELL.trim() ? env.SHELL : "/bin/zsh";
  return { bin, args: ["-il"] };
}

// src/mcp/archetype/mcp-config.ts
var import_path4 = require("path");
function resolveArchetypeMcpEntry(dir, exists) {
  const base = dir.includes("app.asar") ? dir.replace("app.asar", "app.asar.unpacked") : dir;
  const sibling = (0, import_path4.join)(base, "..", "out-mcp", "index.cjs");
  const inDir = (0, import_path4.join)(base, "out-mcp", "index.cjs");
  if (exists(sibling)) return sibling;
  if (exists(inDir)) return inDir;
  return sibling;
}
function archetypeMcpArgs(opts) {
  const config = {
    mcpServers: {
      archetype: {
        command: opts.command,
        args: opts.commandArgs,
        env: { ARCHETYPE_HOME: opts.home }
      }
    }
  };
  return ["--mcp-config", JSON.stringify(config)];
}

// src/shared/readout.ts
function buildReadoutSteering(path) {
  return [
    `You are running inside Olivetti, embedded in a document as a session card.`,
    `To report progress or results, write markdown to this file: ${path}`,
    `Overwrite that file each time \u2014 it is the whole read-out, not a log.`,
    `Its FIRST LINE is the headline shown on the collapsed card; everything after it is the body.`,
    `Keep it short: what you did, what it means. Write it when you finish something worth reporting, not on every step.`,
    `If you hit a bug you could not fix, or you deferred something, you may file it as a GitHub issue with \`gh issue create\` \u2014 your working directory is the repository.`,
    `Do not file speculative ideas or suggestions; those belong in your read-out, not in the backlog. File only what you did or could not do. If the human asks you to file issues, do that too.`,
    `Whenever you file anything, end your read-out with a line listing what you filed: "Filed: #12, #13".`
  ].join(" ");
}

// src/shared/archetype-steering.ts
function buildArchetypeSteering(page, readoutPath) {
  const parts = [
    "You are running inside Archetype, an agentic development environment built around documents."
  ];
  if (page) {
    parts.push(
      `This session is embedded in the page \`${page.path}\` at block \`${page.blockId}\`.`
    );
  }
  parts.push(
    "Archetype documents are edited ONLY through the `archetype` MCP tools \u2014 their descriptions and server instructions explain the model. Never read or write the backing .json doc files directly, even when they sit in your working directory: they hold live custom-block state that raw edits silently corrupt."
  );
  if (readoutPath) {
    parts.push(buildReadoutSteering(readoutPath));
  }
  parts.push(
    "If the task at hand does not involve Archetype documents, ignore all of this and work normally."
  );
  return parts.join(" ");
}
function archetypeSteeringArgs(page, readoutPath) {
  return ["--append-system-prompt", buildArchetypeSteering(page, readoutPath)];
}

// src/main/terminal.ts
var BUFFER_BYTES = 256 * 1024;
var CLAUDE_BIN = "claude";
var SKIP_PERMISSIONS = "--dangerously-skip-permissions";
var STARTUP_QUIET_MS = 2e3;
function archetypeMcpEntry() {
  const entry = resolveArchetypeMcpEntry(__dirname, import_fs4.existsSync);
  if (!(0, import_fs4.existsSync)(entry)) {
    console.error(
      `archetype MCP bundle missing: ${entry} \u2014 agents will report the archetype MCP as unavailable. The agentd bundle was packaged without out-mcp/index.cjs (see scripts/build-agentd.mjs).`
    );
  }
  return entry;
}
function archetypeArgs() {
  const home = getActiveWikiHome() ?? defaultWikiHome();
  return archetypeMcpArgs({ home, command: "node", commandArgs: [archetypeMcpEntry()] });
}
var terms = /* @__PURE__ */ new Map();
var everSpawned = /* @__PURE__ */ new Set();
function resolveCwd(cwd) {
  return cwd && (0, import_fs4.existsSync)(cwd) ? cwd : (0, import_os3.homedir)();
}
function openTerminal(sessionId, cwd, onData, onExit, onMeta, launchSpec) {
  const existing = terms.get(sessionId);
  if (existing) {
    if (existing.runtime !== launchSpec.runtime) {
      onData(`\r
Terminal runtime mismatch for ${sessionId}\r
`, true);
      onExit(1);
      return;
    }
    existing.onData = onData;
    existing.onExit = onExit;
    existing.onMeta = onMeta;
    onData(existing.buffer.contents(), true);
    return;
  }
  const dir = resolveCwd(cwd);
  if (launchSpec.runtime === "shell") {
    const { bin, args: args2 } = shellSpawnSpec(process.env);
    let pty;
    try {
      pty = (0, import_node_pty.spawn)(bin, args2, {
        name: "xterm-256color",
        cols: 80,
        rows: 24,
        cwd: dir,
        env: { ...process.env, COLORTERM: "truecolor" }
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      onData(`\r
Failed to launch ${bin}: ${msg}\r
`, false);
      onExit(1);
      return;
    }
    const term = {
      pty,
      runtime: "shell",
      buffer: new RingBuffer(BUFFER_BYTES),
      spawnedAt: Date.now(),
      tail: "",
      onData,
      onExit,
      onMeta
    };
    terms.set(sessionId, term);
    pty.onData((chunk) => {
      term.buffer.append(chunk);
      term.onData(chunk, false);
    });
    pty.onExit(({ exitCode }) => {
      terms.delete(sessionId);
      term.onExit(exitCode);
    });
    return;
  }
  const args = launchSpec.args;
  const convId = conversationIdOf(args);
  const launch = (launchArgs, canHeal) => {
    let pty;
    try {
      pty = (0, import_node_pty.spawn)(CLAUDE_BIN, [SKIP_PERMISSIONS, ...archetypeArgs(), ...archetypeSteeringArgs(launchSpec.page, launchSpec.readoutPath), ...launchArgs], {
        name: "xterm-256color",
        cols: 80,
        rows: 24,
        cwd: dir,
        env: { ...process.env, COLORTERM: "truecolor" }
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      onData(`\r
Failed to launch \`claude\`: ${msg}\r
`, true);
      onExit(1);
      return;
    }
    const term = {
      pty,
      runtime: "agent",
      buffer: new RingBuffer(BUFFER_BYTES),
      spawnedAt: Date.now(),
      tail: "",
      onData,
      onExit,
      onMeta
    };
    terms.set(sessionId, term);
    if (convId != null) everSpawned.add(convId);
    const resuming = launchArgs[0] === "--resume" || launchArgs[0] === "--continue";
    let healing = false;
    let sawTrust = false;
    let trustHandled = false;
    let lastTrustPoke = 0;
    pty.onData((chunk) => {
      const scan = term.tail + chunk;
      const meta = scanForSessionMeta(scan);
      if (meta.color || meta.name) term.onMeta(meta);
      term.tail = scan.slice(-256);
      if (!trustHandled && isTrustPrompt(scan)) {
        sawTrust = true;
        const now = Date.now();
        if (now - lastTrustPoke > 250) {
          pty.write("\r");
          lastTrustPoke = now;
        }
        term.tail = "";
        return;
      }
      if (sawTrust) trustHandled = true;
      if (canHeal && resuming && (healing || isMissingConversation(scan))) {
        healing = true;
        return;
      }
      term.buffer.append(chunk);
      term.onData(chunk, Date.now() - term.spawnedAt < STARTUP_QUIET_MS);
    });
    pty.onExit(({ exitCode }) => {
      terms.delete(sessionId);
      const recreate = healing ? recreateArgs(launchArgs) : null;
      if (recreate) {
        launch(recreate, false);
        return;
      }
      term.onExit(exitCode);
    });
  };
  launch(launchArgsFor(args, convId != null && everSpawned.has(convId)), convId != null);
}
function listTerminals() {
  return [...terms.keys()];
}
function writeTerminal(sessionId, data) {
  terms.get(sessionId)?.pty.write(data);
}
function readTerminalBuffer(sessionId) {
  return terms.get(sessionId)?.buffer.contents() ?? "";
}
function resizeTerminal(sessionId, cols, rows) {
  try {
    terms.get(sessionId)?.pty.resize(cols, rows);
  } catch {
  }
}
function closeTerminal(sessionId) {
  const term = terms.get(sessionId);
  if (!term) return;
  term.pty.kill();
  terms.delete(sessionId);
}

// src/main/suggestions.ts
var import_fs5 = require("fs");
var import_path5 = require("path");
function suggestionsDir(home) {
  return (0, import_path5.join)((0, import_path5.resolve)(home), ".alexandria", "suggestions");
}
function sidecarPath(home, slug) {
  const root = (0, import_path5.resolve)(home);
  const target = (0, import_path5.resolve)(suggestionsDir(home), `${slug}.json`);
  return target.startsWith(root + import_path5.sep) ? target : null;
}
function clearSuggestions(home, slug) {
  const target = sidecarPath(home, slug);
  if (target) (0, import_fs5.rmSync)(target, { force: true });
}
function readSuggestions(home, slug) {
  const target = sidecarPath(home, slug);
  if (!target || !(0, import_fs5.existsSync)(target)) return null;
  try {
    return (0, import_fs5.readFileSync)(target, "utf8");
  } catch {
    return null;
  }
}

// src/main/projects.ts
var import_fs6 = require("fs");
var import_os4 = require("os");
var import_path6 = require("path");
function conventionalRepoRoot() {
  const dir = (0, import_path6.join)((0, import_os4.homedir)(), "repo");
  return (0, import_fs6.existsSync)((0, import_path6.join)(dir, ".git")) ? dir : null;
}

// src/main/session-store.ts
var import_fs7 = require("fs");
function readSessions(file) {
  try {
    const parsed = JSON.parse((0, import_fs7.readFileSync)(file, "utf8"));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}
function writeSessions(file, sessions) {
  const tmp = file + ".tmp";
  (0, import_fs7.writeFileSync)(tmp, JSON.stringify(sessions, null, 2));
  (0, import_fs7.renameSync)(tmp, file);
}

// src/agentd/trash.ts
var import_fs8 = require("fs");
var import_os5 = require("os");
var import_path7 = require("path");
async function trashPath(p, trashRoot = (0, import_path7.join)((0, import_os5.homedir)(), ".olivetti", "trash")) {
  if (!(0, import_fs8.existsSync)(p)) throw new Error(`trashPath: no such path: ${p}`);
  (0, import_fs8.mkdirSync)(trashRoot, { recursive: true });
  (0, import_fs8.renameSync)(p, (0, import_path7.join)(trashRoot, `${Date.now()}-${(0, import_path7.basename)(p)}`));
}

// src/agentd/readouts.ts
var import_fs9 = require("fs");
var import_path8 = require("path");
function readoutDirFor(wikiDir) {
  return (0, import_path8.join)((0, import_path8.dirname)(wikiDir), "readouts");
}
function readoutPathFor(readoutDir, sessionId) {
  return (0, import_path8.join)(readoutDir, `${sessionId}.md`);
}
function readReadout(path) {
  try {
    return (0, import_fs9.readFileSync)(path, "utf8");
  } catch {
    return "";
  }
}
function sessionIdFromReadoutFile(file) {
  const name = (0, import_path8.basename)(file);
  return name.toLowerCase().endsWith(".md") ? name.slice(0, -3) : null;
}
function watchReadouts(readoutDir, onChange, debounceMs = 200) {
  (0, import_fs9.mkdirSync)(readoutDir, { recursive: true });
  if (!(0, import_fs9.existsSync)(readoutDir)) return null;
  const timers = /* @__PURE__ */ new Map();
  const watcher = (0, import_fs9.watch)(readoutDir, (_event, filename) => {
    if (!filename) return;
    const sessionId = sessionIdFromReadoutFile(String(filename));
    if (!sessionId) return;
    clearTimeout(timers.get(sessionId));
    timers.set(
      sessionId,
      setTimeout(() => {
        timers.delete(sessionId);
        onChange(sessionId, readReadout(readoutPathFor(readoutDir, sessionId)));
      }, debounceMs)
    );
  });
  return watcher;
}

// src/agentd/handlers.ts
function buildHandlers(opts = {}) {
  let readoutWatchStarted = false;
  const sessionsFile = () => {
    const f = opts.sessionsFile ?? (0, import_path9.join)((0, import_os6.homedir)(), ".olivetti", "sessions.json");
    (0, import_fs10.mkdirSync)((0, import_path9.dirname)(f), { recursive: true });
    return f;
  };
  const readoutDir = () => opts.defaultWikiDir ? readoutDirFor(opts.defaultWikiDir) : null;
  const withReadout = (sessionId, launch) => {
    const dir = readoutDir();
    if (!dir || launch.runtime !== "agent") return launch;
    (0, import_fs10.mkdirSync)(dir, { recursive: true });
    return { ...launch, readoutPath: readoutPathFor(dir, sessionId) };
  };
  return {
    [IPC.termOpen]: ({ sessionId, cwd, launch }, ctx) => openTerminal(
      sessionId,
      cwd,
      (chunk, quiet) => ctx.emit(IPC.termData, { sessionId, chunk, quiet }),
      (code) => ctx.emit(IPC.termExit, { sessionId, code }),
      // SESSION_BRIDGE_ENABLED gate from index.ts is deliberately not reproduced here;
      // agentd always emits session meta, and the fragile parsing lives in sessionMeta.ts/session-confirm.ts.
      (meta) => ctx.emit(IPC.sessionMeta, { kind: "pty", sessionId, name: meta.name, color: meta.color }),
      withReadout(sessionId, launch)
    ),
    [IPC.termInput]: ({ sessionId, data }) => writeTerminal(sessionId, data),
    [IPC.termResize]: ({ sessionId, cols, rows }) => resizeTerminal(sessionId, cols, rows),
    [IPC.termClose]: ({ sessionId }) => closeTerminal(sessionId),
    [IPC.termBuffer]: ({ sessionId }) => readTerminalBuffer(sessionId),
    [IPC.termList]: () => listTerminals(),
    [IPC.listDocs]: ({ dir }) => listDocs(dir),
    [IPC.readDoc]: ({ path, dir }) => readDoc(path, dir),
    [IPC.wikiEnsure]: ({ dir }) => ensureWikiHome(dir ?? opts.defaultWikiDir ?? null),
    [IPC.docsWrite]: ({ path, dir, content }) => writeDoc(path, dir, content),
    [IPC.docsCreate]: ({ dir }) => createDoc(dir),
    [IPC.docsCreateNamed]: ({ dir, title }) => createNamedDoc(dir, title),
    [IPC.docsCreateChild]: ({ home, parentRelPath }) => createChildDoc(home, parentRelPath),
    [IPC.docsCreateInFolder]: ({ home, folderRelPath, title }) => createDocInFolder(home, folderRelPath, title),
    [IPC.docsRename]: ({ path, dir, title }) => renameDoc(path, dir, title),
    [IPC.docsTrash]: ({ path, dir }) => trashPath(guardDocPath(path, dir)),
    [IPC.wikiBuildDir]: ({ home, slug }) => ensureBuildDir(home, slug),
    [IPC.watchDocs]: ({ dir }, ctx) => {
      watchDocs(dir, () => ctx.emit(IPC.docsChanged, void 0));
      const rdir = readoutDir();
      if (rdir && !readoutWatchStarted) {
        readoutWatchStarted = true;
        watchReadouts(rdir, (sessionId, markdown) => {
          ctx.emit(IPC.readoutChanged, { sessionId, markdown });
        });
      }
    },
    [IPC.suggestionsRead]: ({ home, slug }) => readSuggestions(home, slug),
    [IPC.suggestionsClear]: ({ home, slug }) => clearSuggestions(home, slug),
    // Per-project local agentds (defaultWikiDir set) run on the user's machine
    // where ~/repo may exist for unrelated reasons — the desktop answers local
    // projects from its registry instead, so they report no backend repo here.
    [IPC.repoRoot]: () => opts.defaultWikiDir ? null : conventionalRepoRoot(),
    [IPC.sessionsRead]: () => readSessions(sessionsFile()),
    [IPC.sessionsWrite]: ({ sessions }, ctx) => {
      writeSessions(sessionsFile(), sessions);
      ctx.emit(IPC.sessionsChanged, void 0);
    }
  };
}

// src/agentd/server.ts
function startAgentd(opts) {
  const clients = /* @__PURE__ */ new Set();
  const broadcast = (channel, payload) => {
    const msg = JSON.stringify({ t: "evt", channel, payload });
    for (const ws of clients) if (ws.readyState === import_ws.WebSocket.OPEN) ws.send(msg);
  };
  const peers = /* @__PURE__ */ new Map();
  const sendPresence = () => broadcast("presence", { peers: [...peers.values()] });
  const ctx = { emit: broadcast };
  const handlers = buildHandlers(opts);
  const http = (0, import_http.createServer)((req, res) => {
    if (req.url === "/healthz") {
      res.writeHead(200, { "content-type": "text/plain", "access-control-allow-origin": "*" });
      res.end("ok");
    } else {
      res.writeHead(404);
      res.end();
    }
  });
  const wss = new import_ws.WebSocketServer({ server: http, path: "/ws" });
  wss.on("connection", (ws, req) => {
    const url = new URL(req.url ?? "/", "http://sprite");
    if (opts.token) {
      const header = req.headers.authorization;
      const query = url.searchParams.get("token");
      if (header !== `Bearer ${opts.token}` && query !== opts.token) {
        ws.close(4401, "unauthorized");
        return;
      }
    }
    clients.add(ws);
    peers.set(ws, url.searchParams.get("name") ?? "anonymous");
    sendPresence();
    ws.on("close", () => {
      clients.delete(ws);
      peers.delete(ws);
      sendPresence();
    });
    ws.on("message", (raw) => void handleMessage(ws, raw.toString()));
  });
  async function handleMessage(ws, raw) {
    const msg = parseWireMessage(raw);
    if (!msg) return;
    if (msg.t === "evt") {
      try {
        await handlers[msg.channel]?.(msg.payload, ctx);
      } catch (err) {
        console.error(`agentd: event ${msg.channel} failed:`, err);
      }
      return;
    }
    if (msg.t !== "req") return;
    const handler = handlers[msg.channel];
    let res;
    if (!handler) {
      res = { t: "res", id: msg.id, ok: false, error: `unknown channel: ${msg.channel}` };
    } else {
      try {
        const result = await handler(msg.args, ctx);
        res = { t: "res", id: msg.id, ok: true, result: result ?? null };
      } catch (err) {
        res = { t: "res", id: msg.id, ok: false, error: err instanceof Error ? err.message : String(err) };
      }
    }
    if (ws.readyState === import_ws.WebSocket.OPEN) ws.send(JSON.stringify(res));
  }
  return new Promise((resolve4) => {
    http.listen(opts.port, opts.host, () => {
      const addr = http.address();
      const port = typeof addr === "object" && addr ? addr.port : opts.port;
      const address = typeof addr === "object" && addr ? addr.address : "";
      resolve4({
        port,
        address,
        broadcast,
        close: () => new Promise((done) => {
          for (const ws of clients) ws.terminate();
          wss.close(() => http.close(() => done()));
        })
      });
    });
  });
}

// src/agentd/index.ts
process.env.PATH = `${(0, import_os7.homedir)()}/.local/bin:${process.env.PATH ?? ""}`;
async function main() {
  const dataDir = process.env.AGENTD_DATA_DIR;
  const wikiDir = dataDir ? (0, import_path10.join)(dataDir, "Olivetti") : null;
  const home = ensureWikiHome(wikiDir);
  const port = Number(process.env.AGENTD_PORT ?? 8080);
  const agentd = await startAgentd({
    port,
    ...process.env.AGENTD_HOST ? { host: process.env.AGENTD_HOST } : {},
    ...process.env.AGENTD_TOKEN ? { token: process.env.AGENTD_TOKEN } : {},
    ...wikiDir ? { defaultWikiDir: wikiDir } : {},
    ...dataDir ? { sessionsFile: (0, import_path10.join)(dataDir, "sessions.json") } : {}
  });
  watchSessionMeta((metas) => agentd.broadcast("session:meta", { kind: "file", metas }));
  console.log(`agentd listening on :${agentd.port}, wiki at ${home}`);
}
main().catch((err) => {
  console.error("agentd failed to start:", err);
  process.exit(1);
});
